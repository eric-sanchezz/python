print ("Hola, Python!")
print ("Èric Sánchez Velasco")

# Elimineu les cometes dobles 
# SyntaxError: invalid syntax. Perhaps you forgot a comma?

# Elimineu els parentesis
# SyntaxError: Missing parentheses in call to 'print'. Did you mean print(...)?

a = "Benvingut"
b = "al món de Python!"
print(a, b)
print("""Això és una cadena
que ocupa diverses línies
sense necessitat de \n""")